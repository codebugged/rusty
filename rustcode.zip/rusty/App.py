import os
from flask import Flask, request, render_template, send_from_directory, redirect,url_for, Response
import cv2

from PIL import Image, ImageOps
import numpy as np
import shutil



np.set_printoptions(suppress=True)

app = Flask(__name__)
#run_with_ngrok(app)
APP_ROOT = os.path.dirname(os.path.abspath(__file__))

@app.route("/")
def index():
    org=os.path.join(APP_ROOT, 'images/org')
    res=os.path.join(APP_ROOT, 'images/res')
    shutil.rmtree(org)
    os.mkdir(org)
    shutil.rmtree(res)
    os.mkdir(res)
    return render_template("index.html")

@app.route("/upload", methods=["POST"])
def upload():    
    file_name={}
    target = os.path.join(APP_ROOT, 'images/org')
    print(target)
    if not os.path.isdir(target):
            os.mkdir(target)
    else:
        print("Couldn't create upload directory: {}".format(target))
    print(request.files.getlist("file"))
    for upload in request.files.getlist("file"):
        #print(upload)
        #print("{} is the file name".format(upload.filename))
        filename = upload.filename       
        destination = "/".join([target, filename])
       # print ("Accept incoming file:", filename)
       # print ("Save it to:", destination)
        upload.save(destination)
    img_res=[]
    i=1
    folder=os.path.join(APP_ROOT, 'images/org')
    print(folder)
    for image_file in os.listdir(folder):
        if image_file == ".ipynb_checkpoints":
            pass
        else:
            img_path=str(folder)+'/'+str(image_file)
            print(img_path)
            img=cv2.imread(img_path)
            img_hsv=cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
            lower_red = np.array([0,70,70])
            upper_red = np.array([20,200,150])
            mask0 = cv2.inRange(img_hsv, lower_red, upper_red)
            lower_red = np.array([170,70,70])
            upper_red = np.array([180,200,150])
            mask1 = cv2.inRange(img_hsv, lower_red, upper_red)
            mask = mask0+mask1
            img_res.append(np.sum(mask)/255)
            al = cv2.bitwise_and(img,img,mask=mask)
            dst = cv2.addWeighted(img,0.1,al,0.9,0)
            cv2.imwrite("images/res/"+"res"+str(image_file.split("/")[-1].split(".")[0])+'.jpg',dst)
            filename="res"+str(image_file.split("/")[-1].split(".")[0])+'.jpg'
            file_name['filename'+str(i)]=filename
            file_name['filename'+str(i+5)]=str(image_file.split("/")[-1].split(".")[0])+'.jpg'
            i+=1
    print(file_name)
  
    image1=str(file_name["filename1"])
    image2=str(file_name["filename2"])
    image3=str(file_name["filename3"])
    image4=str(file_name["filename4"])
    image5=str(file_name["filename5"])
        
            #rgb_img = Image.fromarray(al,'RGB')
            #rgb_img.save("static/"+ str(ex.split("/")[-1].split(".")[0])+'_rgb.jpg')
            
            #os.remove(image_file)
    
     
        #filename =str(ex.split("/")[-1].split(".")[0])+'_rgb.jpg'
    
    #cv2_imshow(img)
    
    return render_template("complete_display_image.html",image1=image1,
                                                         image2=image2,
                                                         image3=image3,
                                                         image4=image4,
                                                         image5=image5,
                                                         res1=img_res[0],
                                                         res2=img_res[1],
                                                         res3=img_res[2],
                                                         res4=img_res[3],
                                                         res5=img_res[4],
                                                         image11=file_name["filename6"],
                                                         image12=file_name["filename7"],
                                                         image13=file_name["filename8"],
                                                         image14=file_name["filename9"],
                                                         image15=file_name["filename10"])

    
@app.route('/uploadres/<filename>')
def send_image(filename):
    print("images/res/"+filename)
    return send_from_directory("images/res/", filename)

@app.route('/uploadorg/<filename>')
def send_image2(filename):
    print("images/org/"+filename)
    return send_from_directory("images/org/", filename)


@app.route('/go back')
def back():
    return redirect("http://codebugged.com/", code=302)

if __name__ == "__main__":
    app.run(host='0.0.0.0',port=9898,debug=True)
    